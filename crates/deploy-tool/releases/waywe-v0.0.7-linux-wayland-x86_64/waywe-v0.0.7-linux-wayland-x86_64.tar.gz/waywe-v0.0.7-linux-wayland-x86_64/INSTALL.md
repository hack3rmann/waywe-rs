# Install

```shell
sudo ./install.sh
```

# Uninstall

```shell
sudo ./uninstall.sh
```
