#!/usr/bin/bash

cp bin/waywe /usr/bin/waywe
cp bin/waywe-daemon /usr/bin/waywe-daemon
