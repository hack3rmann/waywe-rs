#!/usr/bin/bash

rm ~/.cache/waywe
rm -rf /tmp/waywe
rm /usr/bin/waywe
rm /usr/bin/waywe-daemon
